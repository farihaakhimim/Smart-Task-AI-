
import { GoogleGenAI, Type, Modality, FunctionDeclaration } from "@google/genai";
import { AppLanguage, Task, Priority } from "../types";

// Helper to get client
const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

// Tool Definitions
const controlTools: FunctionDeclaration[] = [
  {
    name: 'changeTheme',
    description: 'Change the application visual theme to Light or Dark mode.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        theme: { type: Type.STRING, enum: ['light', 'dark'] }
      },
      required: ['theme']
    }
  },
  {
    name: 'changeLanguage',
    description: 'Change the application interface language.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        language: { type: Type.STRING, enum: Object.values(AppLanguage) }
      },
      required: ['language']
    }
  },
  {
    name: 'navigate',
    description: 'Navigate to a specific screen in the application.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        screen: { type: Type.STRING, enum: ['chat', 'tasks', 'calendar', 'profile'] }
      },
      required: ['screen']
    }
  }
];

// 1. Complex Chat with Thinking & Tools
export const generateSmartChatResponse = async (
  history: { role: string; parts: { text: string }[] }[],
  lastMessage: string,
  userLanguage: AppLanguage
) => {
  const ai = getAiClient();
  const now = new Date();
  const currentDateTime = now.toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: true });
  
  const systemInstruction = `You are "Smart Task AI".
  
  CONTEXT:
  - Time: ${currentDateTime}
  
  CAPABILITIES:
  1. **Control the App**: You have tools to change the Theme, Language, and Navigate screens. If a user asks "Turn on dark mode" or "Go to calendar", USE THE TOOL.
  2. **Language Agnostic**: Detect user language and reply in it.
  3. **Tasks**: If the user wants to set a reminder/alarm, confirm it verbally. The app handles the actual logic separately.
  4. **Personality**: Professional, helpful, concise.
  `;

  const chat = ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction,
      tools: [{ functionDeclarations: controlTools }],
      thinkingConfig: { thinkingBudget: 1024 }, // Lower thinking budget for faster UI control
    },
    history: history,
  });

  const result = await chat.sendMessage({ message: lastMessage });
  
  // Check for function calls
  const functionCalls = result.functionCalls;
  
  return {
    text: result.text,
    functionCalls: functionCalls
  };
};

// 2. Fast Task Extraction (Gemini 2.5 Flash)
export const extractTasksFromText = async (
  text: string, 
  currentDate: string
): Promise<Task[]> => {
  const ai = getAiClient();
  const now = new Date();
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Current System Time: ${now.toISOString()}. 
    
    Extract actionable tasks from: "${text}". 
    
    RULES:
    1. **Reminders/Alarms**: If the user mentions a specific time (e.g., "Alarm at 3 PM"), calculate 'reminderTime' (ISO 8601).
    2. **Recurrence**: Detect "daily", "weekly".
    3. Return JSON Array or empty array.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            dueDate: { type: Type.STRING },
            reminderTime: { type: Type.STRING },
            priority: { type: Type.STRING, enum: ["High", "Medium", "Low"] },
            category: { type: Type.STRING, enum: ["Work", "Personal", "Birthday", "Shopping", "Other"] },
            recurrence: { type: Type.STRING, enum: ["daily", "weekly", "monthly", "weekdays"], nullable: true }
          },
          required: ["title", "priority"]
        }
      }
    }
  });

  if (response.text) {
    try {
      const tasks = JSON.parse(response.text) as any[];
      return tasks.map(t => ({
        id: crypto.randomUUID(),
        isCompleted: false,
        ...t
      }));
    } catch (e) {
      console.error("Failed to parse tasks", e);
      return [];
    }
  }
  return [];
};

// 3. Grounded Search & Maps (Gemini 2.5 Flash)
export const generateGroundedResponse = async (
  query: string,
  location?: { lat: number; lng: number }
) => {
  const ai = getAiClient();
  
  const tools: any[] = [{ googleSearch: {} }];
  let toolConfig = undefined;

  if (location || query.toLowerCase().includes('where') || query.toLowerCase().includes('location') || query.toLowerCase().includes('near')) {
    tools.push({ googleMaps: {} });
    if (location) {
      toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: location.lat,
            longitude: location.lng
          }
        }
      };
    }
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: query,
    config: {
      tools: tools,
      toolConfig: toolConfig
    }
  });

  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const urls = chunks
    .map((c: any) => {
      if (c.web?.uri) return { uri: c.web.uri, title: c.web.title || 'Web Source' };
      if (c.maps?.uri) return { uri: c.maps.uri, title: c.maps.title || 'Map Location' };
      return null;
    })
    .filter((u: any) => u !== null);

  return {
    text: response.text || "I found some information.",
    groundingUrls: urls
  };
};

// 4. TTS Generation
export const generateSpeech = async (text: string, language: AppLanguage) => {
  const ai = getAiClient();
  
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' }, 
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  return base64Audio;
};
