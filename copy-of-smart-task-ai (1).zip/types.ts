
export enum AppLanguage {
  ENGLISH = 'English',
  BENGALI = 'Bengali',
  CHINESE = 'Chinese',
  JAPANESE = 'Japanese',
  SPANISH = 'Spanish'
}

export enum Priority {
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export type RecurrenceType = 'daily' | 'weekly' | 'monthly' | 'weekdays' | null;

export interface UserProfile {
  name: string;
  avatarUrl: string;
  language: AppLanguage;
  isLoggedIn: boolean;
  theme: 'dark' | 'light';
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string; // ISO String
  reminderTime?: string; // ISO String for specific notification
  isCompleted: boolean;
  priority: Priority;
  category?: string;
  recurrence?: RecurrenceType;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  isThinking?: boolean;
  groundingUrls?: Array<{uri: string, title: string}>;
  audioData?: string; // Base64
  toolCalls?: any[];
}

export type ViewMode = 'chat' | 'tasks' | 'calendar' | 'profile';

// Actions the AI can perform on the App
export type SystemActionType = 
  | 'CHANGE_THEME' 
  | 'CHANGE_LANGUAGE' 
  | 'NAVIGATE'
  | 'CREATE_TASK';

export interface SystemAction {
  type: SystemActionType;
  payload: any;
}

// Translation Dictionary Type
export type TranslationKey = 
  | 'nav_chat' | 'nav_tasks' | 'nav_calendar' | 'nav_profile' 
  | 'welcome_title' | 'welcome_subtitle' | 'get_started' | 'what_your_name'
  | 'chat_placeholder' | 'search_placeholder' | 'thinking'
  | 'tasks_pending' | 'filters' | 'sort' | 'no_tasks' | 'add_task'
  | 'profile_settings' | 'save_changes' | 'saved' | 'theme_label' | 'language_label'
  | 'modal_new_task' | 'modal_edit_task' | 'title_label' | 'desc_label'
  | 'date_label' | 'priority_label' | 'category_label' | 'recurrence_label'
  | 'cancel' | 'create' | 'save' | 'delete_confirm_title' | 'delete_confirm_desc'
  | 'enable_reminder' | 'reminder_label';
