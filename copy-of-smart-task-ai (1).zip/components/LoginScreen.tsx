
import React, { useState } from 'react';
import { Sparkles, ArrowRight, Mail, Chrome, Command, Lock } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (name: string, provider?: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [showEmailInput, setShowEmailInput] = useState(false);

  const handleProviderLogin = (provider: string) => {
    // Simulating Secure Auth
    onLogin(provider === 'google' ? 'Google User' : 'Apple User', provider);
  };

  return (
    <div className="h-screen w-full bg-black flex flex-col items-center justify-center p-4 overflow-hidden relative">
       {/* Futuristic Background */}
       <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-blue-900/20 rounded-full blur-[120px]" />
       <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-cyan-900/20 rounded-full blur-[120px]" />
       <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gray-900/50 via-black to-black opacity-80" />

       <div className="z-10 w-full max-w-md">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-black border border-blue-500/30 rounded-3xl mb-6 shadow-2xl shadow-blue-500/20 relative overflow-hidden group">
              <div className="absolute inset-0 bg-blue-600/10 group-hover:bg-blue-600/20 transition-colors" />
              <Sparkles className="w-10 h-10 text-blue-500" />
            </div>
            <h1 className="text-5xl font-bold text-white mb-4 tracking-tighter">Smart Task AI</h1>
            <p className="text-gray-400 text-lg">Intelligent reasoning for your life.</p>
          </div>

          <div className="bg-gray-900/60 backdrop-blur-2xl border border-gray-800 rounded-3xl p-8 shadow-2xl space-y-5">
            <div className="flex items-center justify-center gap-2 text-xs text-blue-400 font-mono mb-2">
                <Lock className="w-3 h-3" />
                SECURE LOGIN SYSTEM
            </div>
            
            {/* Social Logins */}
            {!showEmailInput && (
              <>
                <button 
                  onClick={() => handleProviderLogin('google')}
                  className="w-full bg-white text-black font-semibold py-3.5 rounded-2xl hover:bg-gray-100 transition-colors flex items-center justify-center gap-3 relative group"
                >
                  <Chrome className="w-5 h-5 text-blue-600" />
                  Continue with Google
                </button>

                <button 
                  onClick={() => handleProviderLogin('apple')}
                  className="w-full bg-black text-white border border-gray-700 font-semibold py-3.5 rounded-2xl hover:bg-gray-900 transition-colors flex items-center justify-center gap-3 relative"
                >
                  <Command className="w-5 h-5" />
                  Continue with Apple
                </button>

                <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-gray-800"></div>
                    <span className="flex-shrink mx-4 text-gray-600 text-xs font-medium uppercase">Or</span>
                    <div className="flex-grow border-t border-gray-800"></div>
                </div>

                <button 
                  onClick={() => setShowEmailInput(true)}
                  className="w-full bg-gradient-to-r from-blue-700 to-blue-600 text-white font-semibold py-3.5 rounded-2xl hover:from-blue-600 hover:to-blue-500 transition-all flex items-center justify-center gap-3 shadow-lg shadow-blue-900/20"
                >
                  <Mail className="w-5 h-5" />
                  Continue with Email
                </button>
              </>
            )}

            {/* Email Input Flow */}
            {showEmailInput && (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                <label className="block text-sm font-medium text-gray-400 mb-2">Identify Yourself</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter Name or ID"
                  className="w-full bg-black border border-gray-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-blue-600 outline-none mb-6 transition-all placeholder-gray-700"
                  autoFocus
                />
                
                <div className="flex gap-3">
                   <button 
                    onClick={() => setShowEmailInput(false)}
                    className="flex-1 bg-gray-900/50 text-gray-400 font-medium py-3.5 rounded-2xl hover:bg-gray-800 hover:text-white transition-colors border border-gray-800"
                  >
                    Back
                  </button>
                  <button 
                    onClick={() => name && onLogin(name, 'email')}
                    disabled={!name}
                    className="flex-1 bg-blue-600 text-white font-bold py-3.5 rounded-2xl hover:bg-blue-500 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-600/20"
                  >
                    Login
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex justify-center gap-4 mt-8">
             <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50"></div>
             <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50"></div>
             <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50"></div>
          </div>
       </div>
    </div>
  );
};
