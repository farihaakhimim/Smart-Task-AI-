import React from 'react';
import { ViewMode, UserProfile, TranslationKey } from '../types';
import { LayoutDashboard, MessageSquare, Settings, CheckSquare, LogOut, CalendarDays } from 'lucide-react';

interface SidebarProps {
  currentView: ViewMode;
  setView: (view: ViewMode) => void;
  user: UserProfile;
  onLogout: () => void;
  t: (key: TranslationKey) => string;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, user, onLogout, t }) => {
  const navItems = [
    { id: 'chat' as ViewMode, labelKey: 'nav_chat' as TranslationKey, icon: MessageSquare },
    { id: 'tasks' as ViewMode, labelKey: 'nav_tasks' as TranslationKey, icon: CheckSquare },
    { id: 'calendar' as ViewMode, labelKey: 'nav_calendar' as TranslationKey, icon: CalendarDays },
    { id: 'profile' as ViewMode, labelKey: 'nav_profile' as TranslationKey, icon: Settings },
  ];

  return (
    <div className="w-20 md:w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex flex-col justify-between h-full transition-all duration-300">
      <div>
        <div className="h-16 flex items-center justify-center md:justify-start md:px-6 border-b border-gray-200 dark:border-gray-800">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-md">
            <LayoutDashboard className="text-white w-5 h-5" />
          </div>
          <span className="ml-3 font-bold text-xl text-gray-900 dark:text-white hidden md:block tracking-tight">SmartTask</span>
        </div>

        <nav className="mt-8 px-2 md:px-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`w-full flex items-center justify-center md:justify-start px-3 py-3 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                    : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="ml-3 font-medium hidden md:block">{t(item.labelKey)}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-4 md:p-6 border-t border-gray-200 dark:border-gray-800">
        <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
          <img 
            src={user.avatarUrl} 
            alt="User" 
            className="w-10 h-10 rounded-full object-cover border-2 border-indigo-500"
          />
          <div className="hidden md:block overflow-hidden">
            <p className="font-semibold text-gray-900 dark:text-white truncate text-sm">{user.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{user.language}</p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full flex items-center justify-center md:justify-start px-3 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="ml-3 text-sm font-medium hidden md:block">Logout</span>
        </button>
      </div>
    </div>
  );
};