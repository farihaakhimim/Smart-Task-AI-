
import React, { useState } from 'react';
import { Task, Priority, RecurrenceType, TranslationKey } from '../types';
import { Trash2, Calendar, AlertCircle, Repeat, ArrowUpDown, Filter, Edit2, X, Save, Check, Tag, Clock, Plus, Bell } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  onEditTask: (task: Task) => void;
  onAddNewTask: () => void;
  t: (key: TranslationKey) => string;
}

const CATEGORIES = ['Work', 'Personal', 'Shopping', 'Birthday', 'Other'];

export const TaskList: React.FC<TaskListProps> = ({ tasks, toggleTask, deleteTask, onEditTask, onAddNewTask, t }) => {
  const [sortBy, setSortBy] = useState<'date' | 'priority'>('priority');
  const [filterPriority, setFilterPriority] = useState<Priority | 'All'>('All');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Pending' | 'Completed'>('All');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  
  // Confirmation States
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);

  const getPriorityColor = (p: Priority) => {
    switch (p) {
      case Priority.HIGH: return 'text-red-500 dark:text-red-400 bg-red-100 dark:bg-red-400/10 border-red-200 dark:border-red-400/20';
      case Priority.MEDIUM: return 'text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-400/10 border-yellow-200 dark:border-yellow-400/20';
      case Priority.LOW: return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-400/10 border-green-200 dark:border-green-400/20';
    }
  };

  const getRecurrenceLabel = (r: string) => {
    return (
      <span className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-300 bg-blue-100 dark:bg-blue-500/10 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-500/20">
        <Repeat className="w-3 h-3" />
        {r.charAt(0).toUpperCase() + r.slice(1)}
      </span>
    );
  };

  // Filter Logic
  const filteredTasks = tasks.filter(task => {
    if (filterPriority !== 'All' && task.priority !== filterPriority) return false;
    if (filterStatus === 'Pending' && task.isCompleted) return false;
    if (filterStatus === 'Completed' && !task.isCompleted) return false;
    if (filterCategory !== 'All' && task.category !== filterCategory) return false;
    return true;
  });

  // Sort Logic
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (a.isCompleted && !b.isCompleted) return 1;
    if (!a.isCompleted && b.isCompleted) return -1;

    if (sortBy === 'priority') {
      const priorityWeight = { [Priority.HIGH]: 3, [Priority.MEDIUM]: 2, [Priority.LOW]: 1 };
      const diff = priorityWeight[b.priority] - priorityWeight[a.priority];
      if (diff !== 0) return diff;
    }

    const dateA = a.dueDate ? new Date(a.dueDate).getTime() : Number.MAX_VALUE;
    const dateB = b.dueDate ? new Date(b.dueDate).getTime() : Number.MAX_VALUE;
    return dateA - dateB;
  });

  const confirmDelete = () => {
    if (taskToDelete) {
      deleteTask(taskToDelete);
      setTaskToDelete(null);
    }
  };

  return (
    <div className="h-full relative flex flex-col">
      <div className="flex-1 overflow-y-auto p-6 md:p-10">
        {/* Header & Controls */}
        <div className="flex flex-col gap-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h2 className="text-2xl font-bold flex items-center">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-500">
                {t('nav_tasks')}
              </span>
              <span className="ml-3 text-sm font-normal text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full border border-gray-200 dark:border-gray-700">
                {tasks.filter(t => !t.isCompleted).length} {t('tasks_pending')}
              </span>
            </h2>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-gray-800/50 p-3 rounded-xl border border-gray-200 dark:border-gray-700/50 shadow-sm">
            <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 px-2 border-r border-gray-200 dark:border-gray-700 pr-4 mr-2">
              <Filter className="w-4 h-4" /> {t('filters')}
            </div>

            <select 
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 outline-none"
            >
              <option value="All">All Status</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
            </select>

            <select 
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value as any)}
              className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 outline-none"
            >
              <option value="All">All Priorities</option>
              <option value={Priority.HIGH}>High</option>
              <option value={Priority.MEDIUM}>Medium</option>
              <option value={Priority.LOW}>Low</option>
            </select>

            <select 
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 text-xs rounded-lg px-3 py-2 focus:ring-1 focus:ring-indigo-500 outline-none"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>

            <div className="flex-1" />

            <div className="flex items-center gap-2 text-xs bg-gray-50 dark:bg-gray-900 px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700">
               <span className="text-gray-500 dark:text-gray-500">{t('sort')}:</span>
               <button onClick={() => setSortBy('priority')} className={sortBy === 'priority' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-gray-500 dark:text-gray-400'}>Priority</button>
               <span className="text-gray-300 dark:text-gray-700">|</span>
               <button onClick={() => setSortBy('date')} className={sortBy === 'date' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-gray-500 dark:text-gray-400'}>Date</button>
            </div>
          </div>
        </div>
        
        {/* Empty State */}
        {tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-500">
            <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
              <Calendar className="w-8 h-8 opacity-50" />
            </div>
            <p className="text-lg">{t('no_tasks')}</p>
            <p className="text-sm opacity-60">Add a task manually or ask the AI to "Remind me to..."</p>
          </div>
        )}

        {/* Task List */}
        <div className="space-y-3 pb-20">
          {sortedTasks.length === 0 && tasks.length > 0 && (
            <div className="text-center py-10 text-gray-500 dark:text-gray-500">
              No tasks match your filters.
            </div>
          )}

          {sortedTasks.map((task) => (
            <div 
              key={task.id} 
              className={`group flex items-center justify-between p-4 rounded-xl border transition-all duration-200 ${
                task.isCompleted 
                  ? 'bg-gray-100 dark:bg-gray-900/50 border-gray-200 dark:border-gray-800 opacity-60' 
                  : 'bg-white dark:bg-gray-800/80 border-gray-200 dark:border-gray-700 hover:border-indigo-500/50 hover:shadow-lg hover:shadow-indigo-500/10'
              }`}
            >
              <div className="flex items-start gap-4 overflow-hidden w-full">
                <button 
                  onClick={() => toggleTask(task.id)}
                  className={`mt-1 flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                    task.isCompleted 
                      ? 'bg-green-500 border-green-500' 
                      : 'border-gray-400 dark:border-gray-500 hover:border-indigo-500'
                  }`}
                >
                  {task.isCompleted && <Check className="text-white w-3 h-3" />}
                </button>
                
                <div 
                  className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => onEditTask(task)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className={`font-medium text-lg truncate ${task.isCompleted ? 'line-through text-gray-500 dark:text-gray-500' : 'text-gray-900 dark:text-gray-100'}`}>
                      {task.title}
                    </h3>
                    {task.recurrence && getRecurrenceLabel(task.recurrence)}
                  </div>
                  
                  {task.description && (
                    <p className="text-gray-600 dark:text-gray-400 text-sm truncate mb-2">{task.description}</p>
                  )}
                  
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-md font-medium border ${getPriorityColor(task.priority)}`}>
                      {task.priority}
                    </span>
                    {task.dueDate && (
                      <span className={`text-xs flex items-center gap-1 border border-gray-200 dark:border-gray-700 px-2 py-0.5 rounded-md ${
                        !task.isCompleted && new Date(task.dueDate) < new Date() 
                          ? 'text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-400/5' 
                          : 'text-gray-500 dark:text-gray-400'
                      }`}>
                        <Calendar className="w-3 h-3" />
                        {new Date(task.dueDate).toLocaleDateString()}
                      </span>
                    )}
                    {task.reminderTime && !task.isCompleted && (
                       <span className="text-xs flex items-center gap-1 text-indigo-500 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200 dark:border-indigo-500/20 px-2 py-0.5 rounded-md">
                         <Bell className="w-3 h-3" />
                         {new Date(task.reminderTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                       </span>
                    )}
                    {task.category && (
                      <span className="text-xs text-gray-500 dark:text-gray-500 border border-gray-200 dark:border-gray-700 px-2 py-0.5 rounded-md flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        {task.category}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                 <button 
                  onClick={() => onEditTask(task)}
                  className="text-gray-400 dark:text-gray-600 hover:text-indigo-500 dark:hover:text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setTaskToDelete(task.id)}
                  className="text-gray-400 dark:text-gray-600 hover:text-red-500 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Task FAB */}
      <button
        onClick={onAddNewTask}
        className="absolute bottom-6 right-6 md:bottom-10 md:right-10 w-14 h-14 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-2xl flex items-center justify-center transition-transform hover:scale-110 z-30 ring-2 ring-indigo-400/30"
        title={t('add_task')}
      >
        <Plus className="w-8 h-8" />
      </button>

      {/* Delete Confirmation Modal */}
      {taskToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
           <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 shadow-2xl w-full max-w-sm text-center">
              <div className="w-12 h-12 bg-red-100 dark:bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                 <AlertCircle className="w-6 h-6 text-red-500 dark:text-red-400" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{t('delete_confirm_title')}</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">{t('delete_confirm_desc')}</p>
              
              <div className="flex gap-3 justify-center">
                 <button 
                   onClick={() => setTaskToDelete(null)}
                   className="px-5 py-2.5 rounded-lg border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                 >
                   {t('cancel')}
                 </button>
                 <button 
                   onClick={confirmDelete}
                   className="px-5 py-2.5 rounded-lg bg-red-500 hover:bg-red-600 text-white font-medium shadow-lg shadow-red-500/20 transition-colors"
                 >
                   Yes, Delete
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
