
import React, { useState, useRef, useEffect } from 'react';
import { Message, AppLanguage, Task, TranslationKey, SystemAction } from '../types';
import { generateSmartChatResponse, generateGroundedResponse, extractTasksFromText, generateSpeech } from '../services/geminiService';
import { Send, Globe, MapPin, Sparkles, Volume2, Plus } from 'lucide-react';

interface ChatInterfaceProps {
  messages: Message[];
  addMessage: (msg: Message) => void;
  addTasks: (tasks: Task[]) => void;
  userLanguage: AppLanguage;
  setThinking: (isThinking: boolean) => void;
  isThinking: boolean;
  openTaskModal: () => void;
  onSystemAction: (action: SystemAction) => void; // New prop for system control
  t: (key: TranslationKey) => string;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  messages, addMessage, addTasks, userLanguage, setThinking, isThinking, openTaskModal, onSystemAction, t 
}) => {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'chat' | 'search'>('chat');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  useEffect(() => {
    if (audioUrl && audioRef.current) {
      audioRef.current.play();
    }
  }, [audioUrl]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };
    addMessage(userMsg);
    setInput('');
    setThinking(true);

    try {
      let responseText = '';
      let groundingUrls: {uri: string, title: string}[] = [];

      // 1. Check for tasks in parallel
      const extractedTasks = await extractTasksFromText(userMsg.text, new Date().toISOString());
      if (extractedTasks.length > 0) {
        addTasks(extractedTasks);
      }

      // 2. Main Response Generation
      if (mode === 'search') {
        let location = undefined;
        if (navigator.geolocation) {
          try {
            const pos = await new Promise<GeolocationPosition>((resolve, reject) => 
              navigator.geolocation.getCurrentPosition(resolve, reject, {timeout: 5000})
            );
            location = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          } catch (e) {
            console.warn("Location denied or timeout");
          }
        }
        
        const groundedRes = await generateGroundedResponse(userMsg.text, location);
        responseText = groundedRes.text;
        groundingUrls = groundedRes.groundingUrls;
      } else {
        const history = messages.slice(-10).map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        }));
        
        // Smart Chat with Tools
        const res = await generateSmartChatResponse(history, userMsg.text, userLanguage);
        responseText = res.text || "Processed.";
        
        // Execute Tools if present
        if (res.functionCalls) {
          for (const call of res.functionCalls) {
            if (call.name === 'changeTheme') {
              onSystemAction({ type: 'CHANGE_THEME', payload: call.args.theme });
              responseText += `\n[System] Theme changed to ${call.args.theme}.`;
            } else if (call.name === 'changeLanguage') {
              onSystemAction({ type: 'CHANGE_LANGUAGE', payload: call.args.language });
              responseText += `\n[System] Language changed to ${call.args.language}.`;
            } else if (call.name === 'navigate') {
              onSystemAction({ type: 'NAVIGATE', payload: call.args.screen });
              responseText += `\n[System] Navigating to ${call.args.screen}.`;
            }
          }
        }
      }

      if (extractedTasks.length > 0) {
        responseText += `\n\nI've also added ${extractedTasks.length} task(s) to your list.`;
      }

      const aiMsg: Message = {
        id: crypto.randomUUID(),
        role: 'model',
        text: responseText,
        timestamp: Date.now(),
        groundingUrls
      };
      addMessage(aiMsg);

    } catch (error) {
      console.error(error);
      addMessage({
        id: crypto.randomUUID(),
        role: 'model',
        text: "I'm sorry, I encountered an error processing that request.",
        timestamp: Date.now()
      });
    } finally {
      setThinking(false);
    }
  };

  const handleTTS = async (text: string) => {
    try {
      const base64 = await generateSpeech(text, userLanguage);
      if (base64) {
        const byteCharacters = atob(base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'audio/mp3' }); 
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      }
    } catch (e) {
      console.error("TTS Failed", e);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-black relative transition-colors duration-300">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] md:max-w-[70%] rounded-2xl p-4 shadow-md ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-tl-none border border-gray-200 dark:border-gray-800'
            }`}>
              <div className="whitespace-pre-wrap leading-relaxed">{msg.text}</div>
              
              {/* Grounding Chips */}
              {msg.groundingUrls && msg.groundingUrls.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {msg.groundingUrls.map((g, idx) => (
                    <a 
                      key={idx} 
                      href={g.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs bg-gray-100 dark:bg-black/50 hover:bg-gray-200 dark:hover:bg-gray-800 text-blue-600 dark:text-blue-400 px-2 py-1 rounded border border-gray-300 dark:border-gray-700 transition-colors"
                    >
                      {g.uri.includes('google.com/maps') ? <MapPin className="w-3 h-3"/> : <Globe className="w-3 h-3"/>}
                      {g.title}
                    </a>
                  ))}
                </div>
              )}

              {/* TTS Button for Model */}
              {msg.role === 'model' && (
                <div className="mt-2 flex justify-end">
                   <button onClick={() => handleTTS(msg.text)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors p-1">
                     <Volume2 className="w-4 h-4" />
                   </button>
                </div>
              )}
            </div>
          </div>
        ))}
        
        {isThinking && (
          <div className="flex justify-start">
             <div className="bg-white dark:bg-gray-900 rounded-2xl rounded-tl-none p-4 border border-gray-200 dark:border-gray-800 flex items-center gap-3 shadow-sm">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                <span className="text-xs text-gray-500 dark:text-gray-400 animate-pulse">{t('thinking')}</span>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white dark:bg-black border-t border-gray-200 dark:border-gray-800 transition-colors duration-300">
        <div className="max-w-4xl mx-auto flex flex-col gap-2">
           {/* Tools Toggle */}
           <div className="flex gap-2">
              <button 
                onClick={() => setMode('chat')}
                className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium transition-all ${mode === 'chat' ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 ring-1 ring-blue-500/50' : 'bg-gray-100 dark:bg-gray-900 text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
              >
                <Sparkles className="w-3 h-3" />
                Smart Chat
              </button>
              <button 
                onClick={() => setMode('search')}
                className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium transition-all ${mode === 'search' ? 'bg-cyan-100 dark:bg-cyan-900/40 text-cyan-600 dark:text-cyan-300 ring-1 ring-cyan-500/50' : 'bg-gray-100 dark:bg-gray-900 text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
              >
                <Globe className="w-3 h-3" />
                Web Search & Maps
              </button>
           </div>

           <div className="relative flex items-center gap-2">
              <button 
                onClick={openTaskModal}
                className="p-3 bg-gray-100 dark:bg-gray-900 text-gray-500 dark:text-gray-400 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-blue-600 dark:hover:text-white transition-colors"
                title={t('add_task')}
              >
                <Plus className="w-6 h-6" />
              </button>
              <div className="relative flex-1">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={mode === 'search' ? t('search_placeholder') : t('chat_placeholder')}
                  className="w-full bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white rounded-xl pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none h-14 placeholder-gray-500 dark:placeholder-gray-600 transition-colors"
                />
                <button 
                  onClick={handleSend}
                  disabled={isThinking || !input.trim()}
                  className="absolute right-2 top-2 p-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
           </div>
           <p className="text-center text-xs text-gray-400 dark:text-gray-600 mt-1">
             Gemini can make mistakes. Check important info.
           </p>
        </div>
      </div>
      
      {/* Hidden Audio Player */}
      <audio ref={audioRef} src={audioUrl || undefined} className="hidden" />
    </div>
  );
};
