
import React, { useState, useEffect } from 'react';
import { Task, Priority, RecurrenceType, TranslationKey, AppLanguage } from '../types';
import { X, Save, Plus, Edit2, Clock, AlertCircle, Tag, Repeat, Bell } from 'lucide-react';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskToEdit: Task | null;
  onSave: (task: Task) => void;
  t: (key: TranslationKey) => string;
}

const CATEGORIES = ['Work', 'Personal', 'Shopping', 'Birthday', 'Other'];

export const TaskModal: React.FC<TaskModalProps> = ({ isOpen, onClose, taskToEdit, onSave, t }) => {
  const [task, setTask] = useState<Task>({
    id: '',
    title: '',
    description: '',
    priority: Priority.MEDIUM,
    isCompleted: false,
    dueDate: new Date().toISOString(),
    category: 'Personal',
    recurrence: null,
    reminderTime: undefined
  });

  const [hasReminder, setHasReminder] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (taskToEdit) {
        setTask(taskToEdit);
        setHasReminder(!!taskToEdit.reminderTime);
      } else {
        // Reset for new task
        setTask({
          id: crypto.randomUUID(),
          title: '',
          description: '',
          priority: Priority.MEDIUM,
          isCompleted: false,
          dueDate: new Date().toISOString(),
          category: 'Personal',
          recurrence: null,
          reminderTime: undefined
        });
        setHasReminder(false);
      }
    }
  }, [isOpen, taskToEdit]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTask = { ...task };
    // If reminder toggle is off, clear the reminderTime
    if (!hasReminder) {
      delete finalTask.reminderTime;
    } else if (!finalTask.reminderTime && finalTask.dueDate) {
      // If enabled but null, default to due date
      finalTask.reminderTime = finalTask.dueDate;
    }
    onSave(finalTask);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-lg border border-gray-200 dark:border-gray-700 shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            {taskToEdit ? <Edit2 className="w-5 h-5 text-indigo-500 dark:text-indigo-400" /> : <Plus className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />}
            {taskToEdit ? t('modal_edit_task') : t('modal_new_task')}
          </h3>
          <button onClick={onClose} className="text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('title_label')}</label>
              <input 
                type="text" 
                value={task.title}
                onChange={e => setTask({...task, title: e.target.value})}
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-3 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                required
                autoFocus
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('desc_label')}</label>
              <textarea 
                value={task.description || ''}
                onChange={e => setTask({...task, description: e.target.value})}
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-3 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none min-h-[100px] resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('date_label')}</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input 
                    type="datetime-local" 
                    value={task.dueDate ? new Date(task.dueDate).toISOString().slice(0, 16) : ''}
                    onChange={e => setTask({...task, dueDate: e.target.value ? new Date(e.target.value).toISOString() : undefined})}
                    className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg pl-10 pr-3 py-2.5 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('priority_label')}</label>
                <div className="relative">
                    <AlertCircle className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <select 
                      value={task.priority}
                      onChange={e => setTask({...task, priority: e.target.value as Priority})}
                      className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg pl-10 pr-3 py-2.5 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                    >
                      <option value={Priority.HIGH}>High</option>
                      <option value={Priority.MEDIUM}>Medium</option>
                      <option value={Priority.LOW}>Low</option>
                    </select>
                </div>
              </div>
            </div>

            {/* Reminder Section */}
            <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-700/50">
               <div className="flex items-center justify-between mb-3">
                 <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={hasReminder} 
                      onChange={(e) => {
                        setHasReminder(e.target.checked);
                        if(e.target.checked && !task.reminderTime) {
                           // Default to due date or now
                           setTask({...task, reminderTime: task.dueDate || new Date().toISOString()});
                        }
                      }}
                      className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                    />
                    <Bell className="w-4 h-4 text-indigo-500" />
                    {t('enable_reminder')}
                 </label>
               </div>
               
               {hasReminder && (
                 <div className="animate-in fade-in slide-in-from-top-2 duration-200">
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('reminder_label')}</label>
                    <input 
                      type="datetime-local" 
                      value={task.reminderTime ? new Date(task.reminderTime).toISOString().slice(0, 16) : ''}
                      onChange={e => setTask({...task, reminderTime: e.target.value ? new Date(e.target.value).toISOString() : undefined})}
                      className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2.5 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                 </div>
               )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('category_label')}</label>
                <div className="relative">
                    <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <select 
                      value={task.category || ''}
                      onChange={e => setTask({...task, category: e.target.value})}
                      className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg pl-10 pr-3 py-2.5 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                    >
                      <option value="">No Category</option>
                      {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">{t('recurrence_label')}</label>
                <div className="relative">
                    <Repeat className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <select 
                      value={task.recurrence || ''}
                      onChange={e => setTask({...task, recurrence: e.target.value ? e.target.value as RecurrenceType : null})}
                      className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg pl-10 pr-3 py-2.5 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                    >
                      <option value="">None</option>
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="weekdays">Weekdays</option>
                    </select>
                </div>
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-3">
              <button 
                type="button" 
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                {t('cancel')}
              </button>
              <button 
                type="submit"
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition-all"
              >
                <Save className="w-4 h-4" />
                {taskToEdit ? t('save') : t('create')}
              </button>
            </div>
        </form>
      </div>
    </div>
  );
};
