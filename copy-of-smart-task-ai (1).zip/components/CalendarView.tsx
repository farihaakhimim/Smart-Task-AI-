
import React, { useState } from 'react';
import { Task, Priority, TranslationKey } from '../types';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Globe, Moon, Sun, Star, Gift } from 'lucide-react';

interface CalendarViewProps {
  tasks: Task[];
  t: (key: TranslationKey) => string;
}

// Expanded Holidays (Mock data for 2024-2025 cycle)
const HOLIDAYS: Record<string, { name: string, type: 'religious' | 'international' | 'other' }> = {
  '1-1': { name: 'New Year\'s Day', type: 'international' },
  '2-14': { name: 'Valentine\'s Day', type: 'other' },
  '2-21': { name: 'Intl. Mother Language Day', type: 'international' },
  '3-8': { name: 'Intl. Women\'s Day', type: 'international' },
  '3-31': { name: 'Eid al-Fitr (Approx)', type: 'religious' }, // 2025 approx
  '4-14': { name: 'Pohela Boishakh', type: 'other' },
  '5-1': { name: 'Labour Day', type: 'international' },
  '6-7': { name: 'Eid al-Adha (Approx)', type: 'religious' }, // 2025 approx
  '10-2': { name: 'Durga Puja', type: 'religious' }, // 2025
  '10-31': { name: 'Halloween', type: 'other' },
  '12-25': { name: 'Christmas Day', type: 'religious' },
  '12-31': { name: 'New Year\'s Eve', type: 'other' },
};

export const CalendarView: React.FC<CalendarViewProps> = ({ tasks, t }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const getPriorityDot = (p: Priority) => {
    switch (p) {
      case Priority.HIGH: return 'bg-red-500';
      case Priority.MEDIUM: return 'bg-yellow-500';
      case Priority.LOW: return 'bg-green-500';
    }
  };

  const getHolidayIcon = (type: string) => {
      switch(type) {
          case 'religious': return <Moon className="w-3 h-3 text-purple-400" />;
          case 'international': return <Globe className="w-3 h-3 text-blue-400" />;
          default: return <Star className="w-3 h-3 text-yellow-400" />;
      }
  };

  const renderDays = () => {
    const days = [];
    // Padding
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="h-28 md:h-36 bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-800/50"></div>);
    }

    // Days
    for (let day = 1; day <= daysInMonth; day++) {
      const dateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
      const dateStr = dateObj.toDateString();
      const monthDayKey = `${currentDate.getMonth() + 1}-${day}`;
      const holiday = HOLIDAYS[monthDayKey];

      const dayTasks = tasks.filter(t => {
          if (!t.dueDate) return false;
          return new Date(t.dueDate).toDateString() === dateStr && !t.isCompleted;
      });

      const isToday = new Date().toDateString() === dateStr;
      const isBirthday = dayTasks.some(t => t.category === 'Birthday');

      days.push(
        <div 
          key={day} 
          className={`h-28 md:h-36 border border-gray-200 dark:border-gray-800 p-2 overflow-hidden hover:bg-gray-100 dark:hover:bg-gray-900 transition-all relative group ${
            isToday ? 'bg-blue-50 dark:bg-blue-900/10 shadow-inner' : 'bg-white dark:bg-black'
          }`}
        >
          <div className="flex justify-between items-start mb-1">
            <span className={`text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full ${
              isToday ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'text-gray-500 dark:text-gray-400'
            }`}>
              {day}
            </span>
            
            {isBirthday && (
                <Gift className="w-4 h-4 text-pink-500 animate-pulse" />
            )}
          </div>
          
          {/* Holiday Indicator */}
          {holiday && (
             <div className="mb-2 text-[10px] font-medium text-purple-600 dark:text-purple-300 truncate flex items-center gap-1 bg-purple-100 dark:bg-purple-900/30 px-1.5 py-0.5 rounded border border-purple-200 dark:border-purple-800">
                {getHolidayIcon(holiday.type)}
                {holiday.name}
             </div>
          )}

          <div className="space-y-1 mt-1 overflow-y-auto max-h-[60%] scrollbar-hide">
            {dayTasks.map(task => (
              <div 
                key={task.id} 
                className={`text-[10px] truncate rounded px-1.5 py-1 border flex items-center gap-1.5 ${
                    task.category === 'Birthday' 
                    ? 'bg-pink-100 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-300'
                    : 'bg-gray-100 dark:bg-gray-900 border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300'
                }`}
                title={task.title}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${getPriorityDot(task.priority)} flex-shrink-0`} />
                <span className="truncate">{task.title}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return days;
  };

  return (
    <div className="p-4 md:p-8 h-full flex flex-col bg-gray-50 dark:bg-black">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
            <div className="p-2 bg-blue-600 rounded-xl shadow-lg shadow-blue-600/20">
              <CalendarIcon className="w-6 h-6 text-white" />
            </div>
            {t('nav_calendar')}
        </h2>
        <div className="flex items-center gap-4 bg-white dark:bg-gray-900 rounded-xl p-1.5 border border-gray-200 dark:border-gray-800 shadow-sm">
          <button onClick={prevMonth} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-400 transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-sm font-semibold w-36 text-center text-gray-900 dark:text-white">
            {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </span>
          <button onClick={nextMonth} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-400 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-800 rounded-t-2xl border-b border-gray-200 dark:border-gray-800 overflow-hidden">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
          <div key={d} className="p-4 text-center text-xs font-bold text-gray-500 dark:text-gray-500 uppercase tracking-widest bg-gray-50 dark:bg-gray-900">
            {d}
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-b-2xl overflow-hidden flex-1 auto-rows-fr shadow-xl">
        {renderDays()}
      </div>
    </div>
  );
};
