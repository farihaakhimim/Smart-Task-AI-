import React, { useState, useRef } from 'react';
import { UserProfile, AppLanguage, TranslationKey } from '../types';
import { Save, User, Globe, Upload, Moon, Sun, Camera } from 'lucide-react';

interface ProfileSettingsProps {
  user: UserProfile;
  onUpdate: (user: UserProfile) => void;
  t: (key: TranslationKey) => string;
}

export const ProfileSettings: React.FC<ProfileSettingsProps> = ({ user, onUpdate, t }) => {
  const [formData, setFormData] = useState(user);
  const [isSaved, setIsSaved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setFormData({ ...formData, avatarUrl: result });
      };
      reader.readAsDataURL(file);
    }
  };

  const languages = Object.values(AppLanguage);

  return (
    <div className="p-6 md:p-10 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white">{t('profile_settings')}</h2>
      
      <div className="max-w-2xl bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700 shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Avatar Section */}
          <div className="flex items-center gap-6 mb-8">
            <div className="relative group">
              <img 
                src={formData.avatarUrl} 
                alt="Avatar" 
                className="w-24 h-24 rounded-full object-cover border-4 border-gray-200 dark:border-gray-700 shadow-lg group-hover:border-indigo-500 transition-colors"
              />
              <button 
                type="button" 
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 bg-indigo-600 p-2 rounded-full text-white hover:bg-indigo-500 transition-colors shadow-md"
              >
                <Camera className="w-4 h-4" />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                className="hidden" 
                accept="image/*"
              />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Profile Photo</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Upload a photo to personalize your experience.</p>
            </div>
          </div>

          {/* Name Input */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-600 dark:text-gray-300">
              <User className="w-4 h-4 mr-2" />
              Display Name
            </label>
            <input 
              type="text"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-3 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all"
            />
          </div>

          {/* Theme Select */}
          <div className="space-y-2">
             <label className="flex items-center text-sm font-medium text-gray-600 dark:text-gray-300">
              {formData.theme === 'dark' ? <Moon className="w-4 h-4 mr-2" /> : <Sun className="w-4 h-4 mr-2" />}
              {t('theme_label')}
            </label>
            <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-lg">
               <button
                 type="button"
                 onClick={() => setFormData({...formData, theme: 'light'})}
                 className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${formData.theme === 'light' ? 'bg-white shadow text-indigo-600' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
               >
                 Light
               </button>
               <button
                 type="button"
                 onClick={() => setFormData({...formData, theme: 'dark'})}
                 className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${formData.theme === 'dark' ? 'bg-gray-800 shadow text-indigo-400' : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'}`}
               >
                 Dark
               </button>
            </div>
          </div>

          {/* Language Select */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-medium text-gray-600 dark:text-gray-300">
              <Globe className="w-4 h-4 mr-2" />
              {t('language_label')}
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {languages.map(lang => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => setFormData({...formData, language: lang})}
                  className={`px-4 py-2 rounded-lg text-sm border transition-all ${
                    formData.language === lang
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-gray-400 dark:hover:border-gray-500'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
              The AI will communicate with you primarily in this language.
            </p>
          </div>

          <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
             <button 
               type="submit"
               className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold py-3 rounded-lg shadow-lg flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02]"
             >
               <Save className="w-5 h-5" />
               {isSaved ? t('saved') : t('save_changes')}
             </button>
          </div>
        </form>
      </div>
    </div>
  );
};