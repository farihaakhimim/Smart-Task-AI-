
import React, { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatInterface } from './components/ChatInterface';
import { TaskList } from './components/TaskList';
import { ProfileSettings } from './components/ProfileSettings';
import { LoginScreen } from './components/LoginScreen';
import { CalendarView } from './components/CalendarView';
import { TaskModal } from './components/TaskModal';
import { Task, Message, UserProfile, AppLanguage, ViewMode, TranslationKey, SystemAction } from './types';
import { translations } from './utils/translations';

// Initial Mock Data
const INITIAL_USER: UserProfile = {
  name: '',
  avatarUrl: 'https://picsum.photos/200/200',
  language: AppLanguage.ENGLISH,
  isLoggedIn: false,
  theme: 'dark'
};

const INITIAL_MESSAGE: Message = {
  id: 'welcome-1',
  role: 'model',
  text: "Hello! I am Smart Task AI. I can control your app settings, organize tasks, answer questions, or just chat. How can I help you today?",
  timestamp: Date.now()
};

const App: React.FC = () => {
  // Load from LocalStorage or use Initial
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('smartTaskUser');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('smartTaskMessages');
    return saved ? JSON.parse(saved) : [INITIAL_MESSAGE];
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('smartTaskTasks');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentView, setCurrentView] = useState<ViewMode>('chat');
  const [isThinking, setThinking] = useState(false);
  const [isTaskModalOpen, setTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  
  // Alarm Audio Ref
  const alarmAudioRef = useRef<HTMLAudioElement | null>(null);

  // Effects for Persistence
  useEffect(() => {
    localStorage.setItem('smartTaskUser', JSON.stringify(user));
    if (user.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('smartTaskMessages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('smartTaskTasks', JSON.stringify(tasks));
  }, [tasks]);

  // Notification & Alarm Logic
  useEffect(() => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }
    // Using a reliable beep sound
    alarmAudioRef.current = new Audio("https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg");

    const checkReminders = setInterval(() => {
      const now = new Date();
      tasks.forEach(task => {
        if (task.reminderTime && !task.isCompleted) {
          const reminderTime = new Date(task.reminderTime);
          const timeDiff = reminderTime.getTime() - now.getTime();
          
          if (timeDiff <= 0 && timeDiff > -30000) {
            alarmAudioRef.current?.play().catch(e => console.log("Audio play failed", e));
            
            if (Notification.permission === 'granted') {
               // Real Browser Notification
               new Notification(`Smart Task AI Reminder`, {
                 body: `It's time for: ${task.title}`,
                 icon: 'https://cdn-icons-png.flaticon.com/512/3233/3233497.png'
               });
            }
          }
        }
      });
    }, 10000); 

    return () => clearInterval(checkReminders);
  }, [tasks]);

  // --- Handlers ---

  const handleAiAction = (action: SystemAction) => {
    console.log("AI performing action:", action);
    switch (action.type) {
      case 'CHANGE_THEME':
        setUser(u => ({ ...u, theme: action.payload }));
        break;
      case 'CHANGE_LANGUAGE':
        setUser(u => ({ ...u, language: action.payload }));
        break;
      case 'NAVIGATE':
        setCurrentView(action.payload);
        break;
      default:
        break;
    }
  };

  const handleLogin = (name: string, provider: string = 'email') => {
    setUser({
      ...user,
      name,
      isLoggedIn: true,
      avatarUrl: provider === 'email' ? user.avatarUrl : `https://ui-avatars.com/api/?name=${name}&background=random`
    });
  };

  const handleLogout = () => {
    setUser({ ...user, isLoggedIn: false });
    setMessages([INITIAL_MESSAGE]);
    setCurrentView('chat');
    localStorage.removeItem('smartTaskUser');
    localStorage.removeItem('smartTaskMessages');
  };

  const addMessage = (msg: Message) => {
    setMessages(prev => {
      const updated = [...prev, msg];
      if (updated.length > 50) return updated.slice(-25);
      return updated;
    });
  };

  const addTasks = (newTasks: Task[]) => {
    setTasks(prev => [...prev, ...newTasks]);
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, isCompleted: !t.isCompleted } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const saveTask = (task: Task) => {
    if (tasks.some(t => t.id === task.id)) {
      setTasks(tasks.map(t => t.id === task.id ? task : t));
    } else {
      setTasks([...tasks, task]);
    }
  };

  const openEditTask = (task: Task) => {
    setTaskToEdit(task);
    setTaskModalOpen(true);
  };

  const openNewTask = () => {
    setTaskToEdit(null);
    setTaskModalOpen(true);
  };

  const t = (key: TranslationKey) => {
    return translations[user.language][key] || key;
  };

  if (!user.isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen w-full bg-gray-50 dark:bg-black overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        user={user}
        onLogout={handleLogout}
        t={t}
      />
      
      <main className="flex-1 h-full relative overflow-hidden flex flex-col">
        {currentView === 'chat' && (
          <ChatInterface 
            messages={messages}
            addMessage={addMessage}
            addTasks={addTasks}
            userLanguage={user.language}
            setThinking={setThinking}
            isThinking={isThinking}
            openTaskModal={openNewTask}
            onSystemAction={handleAiAction}
            t={t}
          />
        )}
        
        {currentView === 'tasks' && (
          <TaskList 
            tasks={tasks}
            toggleTask={toggleTask}
            deleteTask={deleteTask}
            onEditTask={openEditTask}
            onAddNewTask={openNewTask}
            t={t}
          />
        )}

        {currentView === 'calendar' && (
          <CalendarView tasks={tasks} t={t} />
        )}

        {currentView === 'profile' && (
          <ProfileSettings 
            user={user}
            onUpdate={setUser}
            t={t}
          />
        )}
      </main>

      <TaskModal 
        isOpen={isTaskModalOpen}
        onClose={() => setTaskModalOpen(false)}
        taskToEdit={taskToEdit}
        onSave={saveTask}
        t={t}
      />
    </div>
  );
};

export default App;
